from currency import Currency
cur = Currency()
cur.start()