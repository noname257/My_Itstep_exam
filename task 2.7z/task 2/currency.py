import boto3
import requests
from boto3.session import Session
import os
from settings import FILENAME, URL
if __name__ == "__main__":
    pass


class Currency:
    def start(self):
        print("Try to get our info from api")
        self.__get_data(URL)

    def __get_data(self, URL):
        responce = requests.get(URL)
        data = responce.json()
        print("Your data form api: ", data)
        print("Saving file...")
        self.__save_to_currency_file(data)
        print("Showing ...")
        self.__show_currencies(data)

    def __save_to_s3(self):
        bucketname = "trashbucket1"
        file_name = "currency.txt"
        AWS_S3_CREDS = {
            "aws_access_key_id": "Enter your keys",
            "aws_secret_access_key": "Enter your keys"
        }
        s3 = boto3.client('s3', **AWS_S3_CREDS)
        s3.upload_file(file_name, bucketname, file_name)

    
    def __save_to_currency_file(self, data):
        with open(FILENAME, "w") as file:
            for item in data:
                file.write(item["ccy"] + " " + item["base_ccy"] +
                           " " + item["buy"] + " " + item["sale"] + "\n")
        self.__save_to_s3()

    def __show_currencies(self, currency):
        print("Inside show_Ccurrency")
        for item in currency:
            print(item["ccy"] + " " + item["base_ccy"] +
                  " " + item["buy"] + " | " + item["sale"])
