if __name__ == "__main__":
    FILENAME,
    URL,

FILENAME = "currency.txt"
URL = "https://api.privatbank.ua/p24api/pubinfo?json&exchange&coursid=5"